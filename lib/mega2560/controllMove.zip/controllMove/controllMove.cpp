#include "controllMove.h"

controllMoveMotor::controllMoveMotor(uint8_t font_left_1_pin,
                                     uint8_t font_left_2_pin,
                                     uint8_t font_right_1_pin,
                                     uint8_t font_right_2_pin,
                                     uint8_t back_left_1_pin,
                                     uint8_t back_left_2_pin,
                                     uint8_t back_right_1_pin,
                                     uint8_t back_right_2_pin) {
  _font_left_1_pin = font_left_1_pin;
  _font_left_2_pin = font_left_2_pin;
  _font_right_1_pin = font_right_1_pin;
  _font_right_2_pin = font_right_2_pin;
  _back_left_1_pin = back_left_1_pin;
  _back_left_2_pin = back_left_2_pin;
  _back_right_1_pin = back_right_1_pin;
  _back_right_2_pin = back_right_2_pin;

  pinMode(_font_left_1_pin, OUTPUT);
  pinMode(_font_left_2_pin, OUTPUT);
  pinMode(_font_right_1_pin, OUTPUT);
  pinMode(_font_right_2_pin, OUTPUT);
  pinMode(_back_left_1_pin, OUTPUT);
  pinMode(_back_left_2_pin, OUTPUT);
  pinMode(_back_right_1_pin, OUTPUT);
  pinMode(_back_right_2_pin, OUTPUT);

  digitalWrite(_font_left_1_pin, LOW);
  digitalWrite(_font_left_2_pin, LOW);
  digitalWrite(_font_right_1_pin, LOW);
  digitalWrite(_font_right_2_pin, LOW);
  digitalWrite(_back_left_1_pin, LOW);
  digitalWrite(_back_left_2_pin, LOW);
  digitalWrite(_back_right_1_pin, LOW);
  digitalWrite(_back_right_2_pin, LOW);
}

void controllMoveMotor::forward(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, speed);
  analogWrite(_font_left_2_pin, 0);

  analogWrite(_font_right_1_pin, speed);
  analogWrite(_font_right_2_pin, 0);

  analogWrite(_back_left_1_pin, speed);
  analogWrite(_back_left_2_pin, 0);

  analogWrite(_back_right_1_pin, speed);
  analogWrite(_back_right_2_pin, 0);
}

void controllMoveMotor::moveLeft(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, 0);
  analogWrite(_font_left_2_pin, speed);

  analogWrite(_font_right_1_pin, speed);
  analogWrite(_font_right_2_pin, 0);

  analogWrite(_back_left_1_pin, speed);
  analogWrite(_back_left_2_pin, 0);

  analogWrite(_back_right_1_pin, 0);
  analogWrite(_back_right_2_pin, speed);
}
void controllMoveMotor::rotateLeft(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, 0);
  analogWrite(_font_left_2_pin, speed);

  analogWrite(_font_right_1_pin, speed);
  analogWrite(_font_right_2_pin, 0);

  analogWrite(_back_left_1_pin, 0);
  analogWrite(_back_left_2_pin, speed);

  analogWrite(_back_right_1_pin, speed);
  analogWrite(_back_right_2_pin, 0);
}
void controllMoveMotor::forwardLeftOblique(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_right_1_pin, speed);
  analogWrite(_font_right_2_pin, 0);

  analogWrite(_back_left_1_pin, speed);
  analogWrite(_back_left_2_pin, 0);
}
void controllMoveMotor::moveRight(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, speed);
  analogWrite(_font_left_2_pin, 0);

  analogWrite(_font_right_1_pin, 0);
  analogWrite(_font_right_2_pin, speed);

  analogWrite(_back_left_1_pin, 0);
  analogWrite(_back_left_2_pin, speed);

  analogWrite(_back_right_1_pin, speed);
  analogWrite(_back_right_2_pin, 0);
}
void controllMoveMotor::rotateRight(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, speed);
  analogWrite(_font_left_2_pin, 0);

  analogWrite(_font_right_1_pin, 0);
  analogWrite(_font_right_2_pin, speed);

  analogWrite(_back_left_1_pin, speed);
  analogWrite(_back_left_2_pin, 0);

  analogWrite(_back_right_1_pin, 0);
  analogWrite(_back_right_2_pin, speed);
}
void controllMoveMotor::forwardRightOblique(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, speed);
  analogWrite(_font_left_2_pin, 0);

  analogWrite(_back_right_1_pin, speed);
  analogWrite(_back_right_2_pin, 0);
}
void controllMoveMotor::back(int16_t speed) {
  if (speed > 255) {
    speed = 255;
  } else if (speed < 0) {
    return;
  }

  analogWrite(_font_left_1_pin, 0);
  analogWrite(_font_left_2_pin, speed);

  analogWrite(_font_right_1_pin, 0);
  analogWrite(_font_right_2_pin, speed);

  analogWrite(_back_left_1_pin, 0);
  analogWrite(_back_left_2_pin, speed);

  analogWrite(_back_right_1_pin, 0);
  analogWrite(_back_right_2_pin, speed);
}